package com.example.weatherapplication.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.weatherapplication.Model.City;
import com.example.weatherapplication.R;
import com.example.weatherapplication.adapter.SearchCityAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AddCityActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    EditText editText;
    ImageView icon_Back;
    DatabaseReference databaseReference;
    FirebaseUser firebaseUser;
    ArrayList<City> cityArrayList;
    SearchCityAdapter searchCityAdapter;
    ImageButton btnSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_city);
        addControl();

        databaseReference = FirebaseDatabase.getInstance().getReference();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = editText.getText().toString();
                setAdapter(s);


            }
        });

    }

    private void addControl() {
        recyclerView = findViewById(R.id.search_city_recycler);
        editText = findViewById(R.id.edt_search);
        icon_Back = findViewById(R.id.icon_back);
        cityArrayList = new ArrayList<>();
        btnSearch = findViewById(R.id.btn_search);
    }

    private void setAdapter( String searchedString){
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot == null) {
                    Toast.makeText(AddCityActivity.this,"Nulllll",Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddCityActivity.this,"NotttNulllll",Toast.LENGTH_SHORT).show();
//                    int count = 0;
//                    cityArrayList.clear();
//                    recyclerView.removeAllViews();
//                    for (DataSnapshot data : dataSnapshot.getChildren()) {
//                        String id = data.child("id").getValue(String.class);
//                        String city = data.child("name").getValue(String.class);
//                        String country = data.child("country").getValue(String.class);
//                        if (city.toLowerCase().contains(searchedString.toLowerCase())) {
//                            City newCity = new City(id, city, country);
//                            count++;
//                            Log.d("tesst", "onDataChange: " + city);
//                            cityArrayList.add(newCity);
//                        }
//                        if (count == 15) {
//                            break;
//                        }
//
//                    }
//
//                    searchCityAdapter = new SearchCityAdapter(AddCityActivity.this, cityArrayList);
//                    recyclerView.setAdapter(searchCityAdapter);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
